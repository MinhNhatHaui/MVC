<?php
/**
 * Created by PhpStorm.
 * User: minhnhat
 * Date: 27/06/2018
 * Time: 10:30
 */
require_once 'config/Database.php';
class Model
{
    protected $db;
    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAll(){
        $sql = "SELECT * FROM {$_GET['controller']} ORDER BY id DESC";
        $res = mysqli_query($this->db->link,$sql);
        $data = [];
        if($res){
            while($num = mysqli_fetch_assoc($res)){
                $data[] = $num;
            }
        }
        return $data;
    }

    public function getOne() {
//        $sql = "SELECT * FROM "
    }

    public function insert( array $data)
    {
        $sql = "INSERT INTO {$_GET['controller']} ";
        $columns = implode(',',array_keys($data));
        $sql .= "( $columns )";
        $values = "";
        foreach($data as $field => $value){
            if(is_string($value)){
                $values .= "'". mysqli_real_escape_string($this->db->link,$value) ."',";
            }else {
                $values .= mysqli_real_escape_string($this->db->link,$values). ',';
            }
        }
        $values = substr($values, 0,-1);
        $sql .= " VALUES (" . $values . ')';
        mysqli_query($this->db->link,$sql) or die("Loi insert----------". mysqli_error($this->link));
        return mysqli_insert_id($this->db->link);
    }

    public function delete($id)
    {
        $sql = "DELETE FROM {$_GET['controller']} WHERE id = {$id}";
        mysqli_query($this->db->link,$sql);
        return mysqli_affected_rows($this->db->link);

    }


}