<?php
/**
 * Created by PhpStorm.
 * User: minhnhat
 * Date: 27/06/2018
 * Time: 12:51
 */
    $view_path = "views";
    $model_path = "models";
    $controller_path= "controllers";

    $host = "kydon-mvc.com";
    $user = "root";
    $password = "123456";
    $database = "QL_THONGTIN";

    define("ROOT","kydon-mvc.com/");
    define("BASE",$_SERVER['DOCUMENT_ROOT']);